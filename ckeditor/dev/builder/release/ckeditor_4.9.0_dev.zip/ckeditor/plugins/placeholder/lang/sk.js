﻿/*
 Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("placeholder","sk",{title:"Vlastnosti placeholdera",toolbar:"Vytvoriť placeholder",name:"Názov placeholdera",invalidName:"Placeholder nemôže byť prázdny a nemôže obsahovať žiadny z nasledujúcich znakov: [,],\x3c,\x3e",pathName:"placeholder"});