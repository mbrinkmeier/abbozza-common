﻿/*
 Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("placeholder","sv",{title:"Innehållsrutans egenskaper",toolbar:"Skapa innehållsruta",name:"Innehållsrutans namn",invalidName:"Innehållsrutan får inte vara tom och får inte innehålla någon av följande tecken: [, ], \x3c, \x3e",pathName:"innehållsruta"});