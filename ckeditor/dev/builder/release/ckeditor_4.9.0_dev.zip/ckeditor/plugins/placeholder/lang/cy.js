﻿/*
 Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("placeholder","cy",{title:"Priodweddau'r Daliwr Geiriau",toolbar:"Daliwr Geiriau",name:"Enw'r Daliwr Geiriau",invalidName:"Dyw'r daliwr geiriau methu â bod yn wag ac na all gynnyws y nodau [, ], \x3c, \x3e ",pathName:"daliwr geiriau"});