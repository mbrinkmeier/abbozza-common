﻿/*
 Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("uicolor","nb",{title:"Fargevelger for brukergrensesnitt",options:"Alternativer for farge",highlight:"Fremhevet",selected:"Valgt farge",predefined:"Forhåndsdefinerte fargesett",config:"Lim inn følgende tekst i din config.js-fil"});